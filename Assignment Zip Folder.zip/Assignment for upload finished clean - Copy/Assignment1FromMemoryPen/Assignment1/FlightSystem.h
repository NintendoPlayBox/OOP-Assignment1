//
//FlightSystem.h
//
//Version: 1.0
//
//Author: Patrick Mc Namee
//
//Date:23/10/2017
//
//Copyright 2017
//

//inclusion of headers and libraries
#include <iostream>
#include <string>
#include <vector>
#include "Aircraft.h"
#pragma once

class FlightSystem {
public:
	//set public methods
	FlightSystem();

	//add aircraft method
	void AddAircraft(std::string flightNumber, std::string airline, std::string aircraftType,
		int groundspeed, int altitude, std::string gridReference, int heading);

	//list all aircraft method
	std::vector<Aircraft> ListAllAircraft();

	//list all cruising aircraft method
	std::vector<Aircraft> ListAllCruisingAircraft();

	//remove aircraft method
	void RemoveAircraft(std::string flightNumber);

	//change heading method
	void ChangeHeading(std::string flightNumber, int heading);

	//get heading method
	int GetHeading(std::string flightNumber);

	//change altitude method
	void ChangeAltitude(std::string flightNumber, int altitude);

	//get altitude method
	int GetAltitude(std::string flightNumber);

	//number of aircraft in sector method
	int NumAircraftInSector();

	//set private variable and method
private:
	//aircraft vector
	std::vector<Aircraft> aircraftList_;
	//bool to check for possible collision
	bool CheckForCollision(std::string flightNumber, int altitude, std::string gridReference);
};