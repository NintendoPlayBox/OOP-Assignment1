//
//FlightSystem.cpp
//
//Version: 1.0
//
//Author: Patrick Mc Namee
//
//Date:23/10/2017
//
//Copyright 2017
//

//inclusion of headers and libraries
#include "FlightSystem.h"
#include "Aircraft.h"
#include <iostream>
#include <string>
#include <vector>

FlightSystem::FlightSystem() {

}

//test for collision of aircraft when adding or changing altitude
bool FlightSystem::CheckForCollision(std::string flightNumber, int altitude, std::string gridReference) {
	for (int i = 0; i < aircraftList_.size(); i++) {
		//test if grid reference same and altitudes of flights within 3000 ft and same grid reference
		if (aircraftList_[i].GetGridReference() == gridReference && aircraftList_[i].GetAltitude() >= altitude - 3000 && aircraftList_[i].GetAltitude() <= altitude + 3000) {
			return true;
		}
	}
	return false;
}

//add aircraft
void FlightSystem::AddAircraft(std::string flightNumber, std::string airline, std::string aircraftType,
	int groundspeed, int altitude, std::string gridReference, int heading) {
	///add aircraft to vector if there is no other objects in vector

	// create a boolean flag that is called isExist. 

	// loop through the vector. Check if the flightnumber you have exists. 

	/// if it exists; set the flag to true.

	/// if the flag is true, print the message, end function. 

	if (aircraftList_.size() < 1) {
		Aircraft aircraft(flightNumber, airline, aircraftType, groundspeed, altitude, gridReference, heading);
		aircraftList_.push_back(aircraft);
		return;
	}

	//check for possible collision
	for (int i = 0; i < aircraftList_.size(); i++) {
		if (aircraftList_[i].GetFlightNumber() != flightNumber) {
			if (CheckForCollision(flightNumber, altitude, gridReference) == true) {
				std::cout << "\nWarning - Aircraft collision possible between " << flightNumber << " and " << aircraftList_[i].GetFlightNumber() << std::endl;
			}
		}
	}

	//set bool
	bool isExist = false;

	for (int i = 0; i < aircraftList_.size(); i++) {
		//check if aircraft already exists
		if (aircraftList_[i].GetFlightNumber() == flightNumber) {
			isExist = true;
		}
		//print if aircraft exists already
		if (isExist == true) {
			std::cout << "Flight " << flightNumber << " already in the system" << std::endl;
		}

		//if aircraft does not already exist, add the aircraft
		Aircraft aircraft(flightNumber, airline, aircraftType, groundspeed, altitude, gridReference, heading);
		aircraftList_.push_back(aircraft);
		return;
	}
}

//remove aircraft
void FlightSystem::RemoveAircraft(std::string flightNumber) {
	for (int i = 0; i < aircraftList_.size(); i++) {
		//check for flight number, if it matches remove the aircraft
		if (aircraftList_[i].GetFlightNumber() == flightNumber) {
			aircraftList_.erase(aircraftList_.begin() + i);
			break;
		}
		//if flight number not matched, display message
		else if (i == aircraftList_.size() - 1) {
			std::cout << "Flight " << flightNumber << " is not in the system" << std::endl;
		}
	}
}

//return vector of all aircraft in system
std::vector<Aircraft> FlightSystem::ListAllAircraft() {
	return aircraftList_;
}

//return vector of all aircraft above 30000 ft
std::vector<Aircraft> FlightSystem::ListAllCruisingAircraft() {
	//create new vector
	std::vector<Aircraft> CrusingAircraftList;

	for (int i = 0; i < aircraftList_.size(); i++) {
		//if the altitude of an aircraft is over 30000, add to the new vector
		if (aircraftList_[i].GetAltitude() >= 30000) {
			CrusingAircraftList.push_back(aircraftList_[i]);
		}
	}
	//return the cruising aircraft vector
	return CrusingAircraftList;
}

//change heading of an aircraft
void FlightSystem::ChangeHeading(std::string flightNumber, int heading) {
	for (int i = 0; i <= aircraftList_.size() - 1; i++) {
		//find aircraft in vector with matching flight number
		if (aircraftList_[i].GetFlightNumber() == flightNumber) {
			//set its heading to the given heading
			aircraftList_[i].SetHeading(heading);
			std::cout << "Heading of flight " << flightNumber << " changed to " << aircraftList_[i].GetHeading() << std::endl;
			break;
		}
		//if end of vector, print not found message
		else if (i == aircraftList_.size() - 1) {
			std::cout << "Flight " << flightNumber << " is not in the system";
			return;
		}
	}
}

//return heading of an aircraft
int FlightSystem::GetHeading(std::string flightNumber) {
	for (int i = 0; i < aircraftList_.size(); i++) {
		//find aircraft in vector with matching flight number
		if (aircraftList_[i].GetFlightNumber() == flightNumber) {
			//return heading
			return aircraftList_[i].GetHeading();
		}
		//if end of vector, print not found
		else if (i = aircraftList_.size() + 1) {
			std::cout << "Flight " << flightNumber << " is not in the system";

		}
	}
}

//change altitude of an aircraft
void FlightSystem::ChangeAltitude(std::string flightNumber, int altitude) {
	for (int i = 0; i <= aircraftList_.size() - 1; i++) {
		//find aircraft in vector with matching flight number
		if (aircraftList_[i].GetFlightNumber() == flightNumber) {
			//set altitude to given altitude
			aircraftList_[i].SetAltitude(altitude);
			std::cout << "Altitude of flight " << flightNumber << " changed to " << aircraftList_[i].GetAltitude() << std::endl;
			break;
		}
		//if end of vector found, print not found
		else if (i == aircraftList_.size() - 1) {
			std::cout << "Flight " << flightNumber << " is not in the system";
			return;
		}
	}
	//check for possible collision
	for (int i = 0; i < aircraftList_.size(); i++) {
		if (CheckForCollision(flightNumber, altitude, aircraftList_[i].GetGridReference()) != true && aircraftList_[i].GetFlightNumber() != flightNumber) {
			std::cout << "Warning - Aircraft collision possible between " << flightNumber << " and " << aircraftList_[i].GetFlightNumber() << std::endl;
		}
	}
}

//return altitude of an aircraft
int FlightSystem::GetAltitude(std::string flightNumber) {
	for (int i = 0; i < aircraftList_.size(); i++) {
		//find aircraft in vector with matching flight number
		if (aircraftList_[i].GetFlightNumber() == flightNumber) {
			return aircraftList_[i].GetAltitude();
		}
		//if end of vector, print not found
		else if (i = aircraftList_.size() + 1)
			std::cout << "Flight " << flightNumber << " is not in the system";
	}
}

//list number of aircraft in the system
int FlightSystem::NumAircraftInSector() {
	//set number of aircraft in sector to the size of the airraft list
	int NumAircraftinSector = size(aircraftList_);
	return NumAircraftinSector;
}