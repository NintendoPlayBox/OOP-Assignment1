//
//Aircraft.cpp
//
//Version: 1.0
//
//Author: Patrick Mc Namee
//
//Date:23/10/2017
//
//Copyright 2017
//

//inclusion of headers and libraries
#include "Aircraft.h"
#include <iostream>
#include <vector>
#include <string>

//default constructor
Aircraft::Aircraft() {

}

//contructor
Aircraft::Aircraft(std::string flightNumber, std::string airline, std::string aircraftType,
	int groundspeed, int altitude, std::string gridReference, int heading) :
	flightNumber_{ flightNumber }, airline_{ airline }, aircraftType_{ aircraftType },
	groundSpeed_{ groundspeed }, altitude_{ altitude }, gridReference_{ gridReference },
	heading_{ heading } {}

//flight number setter
void Aircraft::SetFlightNumber(std::string flightNumber) {
	flightNumber_ = flightNumber;
}

//flight number getter
std::string Aircraft::GetFlightNumber() {
	return flightNumber_;
}

//airline setter
void Aircraft::SetAirline(std::string airline) {
	airline_ = airline;
}

//airline getter
std::string Aircraft::GetAirline() {
	return airline_;
}

//aircraft setter
void Aircraft::SetAircraftType(std::string aircraftType) {
	aircraftType_ = aircraftType;
}

//aircraft getter
std::string Aircraft::GetAircraftType() {
	return aircraftType_;
}

//groundspeed setter
void Aircraft::SetGroundSpeed(int groundSpeed) {
	groundSpeed_ = groundSpeed;
}

//groundspeed getter
int Aircraft::GetGroundSpeed() {
	return groundSpeed_;
}

//altitude setter
void Aircraft::SetAltitude(int altitude) {
	altitude_ = altitude;
}

//altitude getter
int Aircraft::GetAltitude() {
	return altitude_;
}

//grid reference setter
void Aircraft::SetGridReference(std::string gridReference) {
	gridReference_ = gridReference;
}

//grid reference getter
std::string Aircraft::GetGridReference() {
	return gridReference_;
}

//heading setter
void Aircraft::SetHeading(int heading) {
	heading_ = heading;
}

//heading getter
int Aircraft::GetHeading() {
	return heading_;
}